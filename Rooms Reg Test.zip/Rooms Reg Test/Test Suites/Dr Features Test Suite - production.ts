<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Dr Features Test Suite - production</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient>graham@medicalchain.com;</mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>44dba252-ff17-4412-a8eb-632b06d51a60</testSuiteGuid>
   <testCaseLink>
      <guid>a9672247-cb48-4c04-86c0-0748adfba608</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Prod/1.Dr login and create clinic (1st)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0c1975dd-4105-4822-afb9-fdc9148151b8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Prod/2.Dr Delete Clinic test 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6f4fe481-5d57-4239-ab5d-d29c2b8d0f7d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Prod/3.Dr login, create clinic, patient signs in (2nd)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>128d06e8-fb09-4ea4-a692-9e8a5a0727e5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Prod/4.Dr Create second Clinic (parallel)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>20040f9a-8a91-4908-ace4-a13adb2a862b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Prod/5.Cleanup (delete all clinics)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
