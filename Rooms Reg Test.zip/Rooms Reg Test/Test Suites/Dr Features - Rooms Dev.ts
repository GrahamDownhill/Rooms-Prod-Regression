<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Dr Features - Rooms Dev</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>ea2c6878-23ff-4bb7-a6f0-8eaa9413dad5</testSuiteGuid>
   <testCaseLink>
      <guid>e9749165-6a06-450a-b76f-e11d118ca7da</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Dev/1.Dr login and create clinic (1st)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>90f99671-1891-4b18-b571-2424f5a1aa11</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Dev/2.Dr Delete Clinic test 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>695b564c-483c-46dc-ad97-1c7ccaea1f2b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Dev/3.Dr login, create clinic, patient signs in (2nd)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8a5eecaa-2559-4d3e-a7b8-6d76cceacbfd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Dev/4.Dr Create second Clinic (parallel)</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0ba3d2c7-4d87-4f10-b36b-881e93635991</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Doctor Features - Dev/5.Cleanup (delete all clinics)</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
