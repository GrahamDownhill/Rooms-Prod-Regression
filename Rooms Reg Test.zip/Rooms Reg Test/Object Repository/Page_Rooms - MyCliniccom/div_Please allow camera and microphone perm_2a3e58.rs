<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Please allow camera and microphone perm_2a3e58</name>
   <tag></tag>
   <elementGuidId>6fd00aa6-04c3-4a1a-8c7b-474b4ea5592a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='root-body']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
    
    
        
    
        
             
        
    



        
        
        

        
            
Please allow camera and microphone permissions. This is required to join the waiting room and to initiate a call with the doctor.                    Allow Video/Audio Permissions
            

            
                
                    Loading...
                 
                Please wait while we try to enable the camera and microphone. Please allow camera and audio permissions on your browser
            
            Doctor's camera is disabled

            Accessing camera and audio has failed. Please refresh the page and try again or use a different browser or device.

            
                
                    Loading...
                 
                Waiting for the doctor.  If this is a life threatening condition dial your local emergency number now.
            

            
The call has been disconnected.                    
                    Reconnect
                    End Call
            

            
                Call ended. Call time was 0 minutes, 0 seconds
                
                Rate this Call:
                
                    
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        
                    
                
                
                    
                         I couldn't hear the patient.
                         The patient couldn't hear me.
                         I couldn't see the patient.
                         The patient couldn't see me.
                         Other 
                    
                
                
                    
                
                
                Submit Feedback
                Back to Clinic
            
        

        

            
                
                zdfhzdfh
            
        
            mic_none
            flip_camera_ios
            settings
        
        
            
                
                    
                        Settings
                        
                            ×
                        
                    
                    
                        
                            Select your audio input (Microphone):
                            
                        
                        
                            Select your audio output (Speaker):
                            
                        
                        
                            Select your camera input (Camera):
                            
                        
                        
                    
                    
                        Cancel
                        Set
                    
                
            
        
    




    
        End Call
    






    
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root-body&quot;)/div[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='root-body']/div</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
   </webElementXpaths>
</WebElementEntity>
